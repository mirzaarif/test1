package com.wakaleo.gameoflife.test.categories;

public interface RegressionTests extends SlowTests {

}
